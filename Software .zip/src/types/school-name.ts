// Define School type
export interface School {
    _id?: string;
    name: string;
    location: string;
    
  }