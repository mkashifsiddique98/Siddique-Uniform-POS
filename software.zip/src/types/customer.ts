export interface customer {
  customerName: string;
  schoolName?: string;
  type?: string;
  phone?: number;
  prevBalance?: number;
  _id:string
}
