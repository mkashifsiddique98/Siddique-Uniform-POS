export  const  calculatePercentage =(part: number , whole: number)=> {
    return Math.floor((part / whole) * 100);
}