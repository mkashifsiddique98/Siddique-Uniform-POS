import { Topnav } from "@/components/layout/topnav";
import React from "react";
import ProductBox from "./Product-Box-Pagnation";
import BillBook from "./bill-book";

async function getAllCustomerDetail() {
  const res = await fetch("http://localhost:3000/api/customer", {
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error("Failed to fetch data");
  }

  return res.json();
}
async function getAllProductData() {
  const res = await fetch("http://localhost:3000/api/product/", {
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error("Failed to fetch data");
  }

  return res.json();
}
const PointOfSale = async () => {
  const data = await getAllProductData();
  const customer = await getAllCustomerDetail();
  const { listCustomer } = customer;
  const { response } = data;
  return (
    <div className="flex">
      {/* Left Side */}
      <div className="h-screen w-6/12 border-r-2 border-black ">
        <Topnav />
        <BillBook  listCustomer={listCustomer}/>
      </div>
      {/* Right Side */}
      <div className="h-screen w-6/12">
        <div className="container">
          <ProductBox items={response} perPage={12} />
        </div>
      </div>
    </div>
  );
};

export default PointOfSale;
